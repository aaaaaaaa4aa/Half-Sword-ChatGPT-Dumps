#ifndef UE4SS_SDK_BP_Armor_Modular_Core_Legs_Cuisse_HPP
#define UE4SS_SDK_BP_Armor_Modular_Core_Legs_Cuisse_HPP

class ABP_Armor_Modular_Core_Legs_Cuisse_C : public ABP_Armor_Modular_Core_Master_C
{
}; // Size: 0xA68

#endif
