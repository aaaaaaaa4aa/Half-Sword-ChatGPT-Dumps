#ifndef UE4SS_SDK_BP_Armor_Head_Kettle_Helm_C_HPP
#define UE4SS_SDK_BP_Armor_Head_Kettle_Helm_C_HPP

class ABP_Armor_Head_Kettle_Helm_C_C : public ABP_Armor_Master_C
{
}; // Size: 0x918

#endif
