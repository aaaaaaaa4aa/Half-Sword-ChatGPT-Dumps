#ifndef UE4SS_SDK_BP_CombatEvent_Tourney_Baron_HPP
#define UE4SS_SDK_BP_CombatEvent_Tourney_Baron_HPP

class ABP_CombatEvent_Tourney_Baron_C : public ABP_CombatEvent_Master_C
{
}; // Size: 0x410

#endif
