#ifndef UE4SS_SDK_BP_Armor_Modular_Module_Spaulder_Rondels_1_HPP
#define UE4SS_SDK_BP_Armor_Modular_Module_Spaulder_Rondels_1_HPP

class ABP_Armor_Modular_Module_Spaulder_Rondels_1_C : public ABP_Armor_Modular_Module_Master_C
{
}; // Size: 0x91C

#endif
