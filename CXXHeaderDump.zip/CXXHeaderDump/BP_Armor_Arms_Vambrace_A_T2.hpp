#ifndef UE4SS_SDK_BP_Armor_Arms_Vambrace_A_T2_HPP
#define UE4SS_SDK_BP_Armor_Arms_Vambrace_A_T2_HPP

class ABP_Armor_Arms_Vambrace_A_T2_C : public ABP_Armor_Master_C
{
}; // Size: 0x918

#endif
